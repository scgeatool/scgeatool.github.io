if (!requireNamespace("RJcluster", quietly = TRUE)){
    install.packages("RJcluster", repo="http://cran.rstudio.com/")
}