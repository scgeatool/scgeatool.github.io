library(devtools)
install_github("ctlab/fgsea")