if (!requireNamespace("uwot", quietly = TRUE)){
    install.packages("uwot", repo="http://cran.rstudio.com/")
}